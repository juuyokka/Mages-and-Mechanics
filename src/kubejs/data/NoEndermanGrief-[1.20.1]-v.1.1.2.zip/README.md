# No Enderman Grief

**Stops enderman from pickung up blocks**

### Enabled

![Enderman do not pick up blocks](https://cdn.modrinth.com/data/cached_images/d71ea7955e7bacbd8307c87c4bc9101a2d903c75.png)

#

### Disabled

![Enderman picking up blocks](https://cdn.modrinth.com/data/cached_images/21de0d2b5968ff59ea1768e49b8f894888ac5f5c.png)

---

## Datapack created by Jodek published on modrinth: https://modrinth.com/user/Jodek

<picture>
   <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/light-theme/tip.svg">
  <img alt="Tip" src="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/dark-theme/tip.svg">
 </picture><br>
 
Questions or issues? -> [discord server](https://discord.gg/z2n3qTzQY6) | _or create an issue on github_
